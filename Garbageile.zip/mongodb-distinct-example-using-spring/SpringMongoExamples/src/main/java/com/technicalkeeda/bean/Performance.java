package com.technicalkeeda.bean;

public class Performance {
	private String topSpeed;
	private String acceleration;
	private String maximumTorque;
	private String noOfCylinders;

	public Performance(String topSpeed, String acceleration,
			String maximumTorque, String noOfCylinders) {
		super();
		this.topSpeed = topSpeed;
		this.acceleration = acceleration;
		this.maximumTorque = maximumTorque;
		this.noOfCylinders = noOfCylinders;
	}

	public String getTopSpeed() {
		return topSpeed;
	}

	public void setTopSpeed(String topSpeed) {
		this.topSpeed = topSpeed;
	}

	public String getAcceleration() {
		return acceleration;
	}

	public void setAcceleration(String acceleration) {
		this.acceleration = acceleration;
	}

	public String getMaximumTorque() {
		return maximumTorque;
	}

	public void setMaximumTorque(String maximumTorque) {
		this.maximumTorque = maximumTorque;
	}

	public String getNoOfCylinders() {
		return noOfCylinders;
	}

	public void setNoOfCylinders(String noOfCylinders) {
		this.noOfCylinders = noOfCylinders;
	}

}
