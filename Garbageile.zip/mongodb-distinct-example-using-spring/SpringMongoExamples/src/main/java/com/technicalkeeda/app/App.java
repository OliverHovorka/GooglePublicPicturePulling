package com.technicalkeeda.app;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;
import com.technicalkeeda.bean.Car;
import com.technicalkeeda.bean.Performance;
import com.technicalkeeda.dao.CarDao;

public class App {
	public static void main(String[] args) {

		try {
			ApplicationContext context = new ClassPathXmlApplicationContext("spring-beans.xml");
			
			CarDao carDao = (CarDao) context.getBean("carDao");
			carDao.drop();

			Car polo = new Car();
			polo.setMake("Volkswagen");
			polo.setModel("Polo GT TSI Petrol");
			polo.setPrice("750000");
			polo.setPerformance(new Performance("190 kmph", "9.7 Seconds","175Nm@1500-4100rpm", "4"));
			carDao.create(polo);

			Car poloDiesel = new Car();
			poloDiesel.setMake("Volkswagen");
			poloDiesel.setModel("Polo 1.5 TDI Highline (Diesel)");
			poloDiesel.setPrice("755000");
			poloDiesel.setPerformance(new Performance("163 Kmph","16.1 Seconds", "230Nm@1500-2500rpm", "5"));
			carDao.create(poloDiesel);
			
			
			
			Car swift = new Car();
			swift.setMake("Maruti Suzuki");
			swift.setModel("Maruti Swift ZDi");
			swift.setPrice("720906");
			swift.setPerformance(new Performance("155 kmph", "14.8 Seconds","190Nm@2000rpm", "4"));
			carDao.create(swift);
			
			Car celerio = new Car();
			celerio.setMake("Maruti Suzuki");
			celerio.setModel("Maruti Celerio ZXI");
			celerio.setPrice("720906");
			celerio.setPerformance(new Performance("150 kmph", "15.05 Seconds","90Nm@3500rpm", "3"));
			carDao.create(celerio);
			
			
			Car grandI10  = new Car();
			grandI10 .setMake("Hyundai");
			grandI10 .setModel("Hyundai Grand i10 CRDi Asta");
			grandI10 .setPrice("674034");
			grandI10 .setPerformance(new Performance("157 kmph", "15.6 Seconds","159.8Nm@1500-2750rpm", "3"));
			carDao.create(grandI10 );

			System.out.println("Find By Make --------------------------");
			
			List byMake = carDao.findByField("make");
			System.out.println(byMake);
			
			System.out.println("Find By Model -------------------------");
			
			List byModel = carDao.findByField("model");
			System.out.println(byModel);
			
			System.out.println("Find By Query --------------------------");
			
			DBObject dbObject = new BasicDBObject("performance.noOfCylinders",new BasicDBObject("$gt","3"));
			
			List findByQuery = carDao.findByQuery("model",dbObject);
			System.out.println(findByQuery);
			
			

		} catch (Exception e) {
			System.out.println("Exception App.java" + e.getMessage());
			e.printStackTrace();

		}

	}
}
