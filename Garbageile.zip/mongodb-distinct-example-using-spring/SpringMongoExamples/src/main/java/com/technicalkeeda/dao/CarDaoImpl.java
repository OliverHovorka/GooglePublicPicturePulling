package com.technicalkeeda.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;

import com.mongodb.DBObject;
import com.technicalkeeda.bean.Car;

public class CarDaoImpl implements CarDao {

	private static final String COLLECTION = "Cars";

	@Autowired
	MongoTemplate mongoTemplate;

	public void create(Car car) {
		if (car != null) {
			this.mongoTemplate.insert(car, COLLECTION);
		}
	}

	public void drop() {
		this.mongoTemplate.dropCollection(COLLECTION);
	}

	@Override
	public List findByField(String field) {
		return mongoTemplate.getCollection(COLLECTION).distinct(field);
	}

	@Override
	public List findByQuery(String field, DBObject dbObject) {
		return mongoTemplate.getCollection(COLLECTION)
				.distinct(field, dbObject);
	}

}