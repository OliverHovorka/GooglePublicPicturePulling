package com.technicalkeeda.dao;

import java.util.List;

import com.mongodb.DBObject;
import com.technicalkeeda.bean.Car;

public interface CarDao {

	public List findByField(String key);

	public List findByQuery(String field, DBObject dbObject);

	public void create(Car car);

	public void drop();
}
